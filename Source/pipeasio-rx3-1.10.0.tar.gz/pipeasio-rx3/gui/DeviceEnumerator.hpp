/*
 * DeviceEnumerator.hpp - list PipeWire sinks/sources for the device combos.
 *
 * parsePwDump() is PURE (operates on a JSON blob, no process spawning) so it
 * is unit testable with a captured fixture.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Copyright (C) 2026 PipeASIO contributors
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <https://www.gnu.org/licenses/>.
 */
#pragma once

#include <QByteArray>
#include <QList>
#include <QObject>
#include <QStringList>
#include <QPointer>
#include <optional>
#include <QString>
class QProcess;
class QTimer;

namespace DeviceEnumerator
{

struct RequestOptions
{
    QString     program = QStringLiteral("pw-dump");
    QStringList arguments;
    int         timeoutMs = 8000;
};

struct Device
{
    QString name;           /* node.name */
    QString description;    /* node.description (fallback node.nick / node.name) */
    bool    isSink = false; /* true: Audio/Sink (output), false: Audio/Source */
};

/* Invalid JSON and non-array top levels return std::nullopt. */
std::optional<QList<Device>> parsePwDump(const QByteArray &json);

/* Current graph sample rate from the "settings" metadata (clock.force-rate
 * when nonzero, else clock.rate), or 0 when unknown.  Pure. */
int graphClockRate(const QByteArray &json);

class Request final : public QObject
{
    Q_OBJECT
  public:
    explicit Request(RequestOptions options = {}, QObject *parent = nullptr);
    ~Request() override;

    void start();

    /* Graph clock rate parsed from the same pw-dump snapshot; valid after
     * finished(success == true), 0 when unknown. */
    int
    graphRate() const
    {
        return m_graphRate;
    }

  signals:
    void finished(bool success, const QList<Device> &devices, const QString &error);

  private:
    void finish(bool success, QList<Device> devices, QString error);

    RequestOptions     m_options;
    QPointer<QProcess> m_process;
    QTimer            *m_timer     = nullptr;
    bool               m_done      = false;
    int                m_graphRate = 0;
};

} // namespace DeviceEnumerator
